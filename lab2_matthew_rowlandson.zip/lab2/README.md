I was able to get the first in first out part of this assignment working.

The Least Frequently used second caused my alot of problems. I couldn't get an algorithm going that would work.

Tutorial Referenced: https://www.youtube.com/watch?v=uL0xP57negc