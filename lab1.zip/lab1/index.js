(function() {
  const App = require('./src/app.js');
  var app = new App(); //extantion of the process
  app.start(); //starting the memory manager
}());